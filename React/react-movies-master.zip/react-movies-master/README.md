# React Workshop

## Configure Environment from CLI

1. Make sure you have node installed. `node -v` (v.6.0.0 or higher)
2. Clone or download repository to your local environment. `git clone https://github.com/dilansri/react-movies.git`
3. Switch to the `react-movies` and run `npm install`
4. Execute `npm run start:before`, navigate into `localhost:3000`, you should see a hello world text in a red background with a placeholder image