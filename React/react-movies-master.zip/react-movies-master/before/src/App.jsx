import React from 'react'

class App extends React.Component {
  render() {
    return (
      <div className="app-container">
        <p>Hello World</p>
        <img alt="placeholder" src={`statics/img/placeholder.png`} />
      </div>
    );
  }
}

export default App
