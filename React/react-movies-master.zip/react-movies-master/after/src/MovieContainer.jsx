import React from 'react'

class MovieContainer extends React.Component{
	render(){
		return (
			<this.props.layout 
				{...this.props}
			/>
		)
	}
}

export default MovieContainer;